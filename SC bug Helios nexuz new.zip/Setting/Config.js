const fs = require('fs')

global.config = {
  botname: "Ex-Machina",
  version: "7.0 VIP",
  packname: "Ainweg",
  owner: "6281241462583",
  footer: "Unit Kämpfer",
  idch: "120363424360946996@newsletter",
  thumb: "https://files.catbox.moe/va2fyh.jpeg",
}

//-------------------- [ SETTINGS ] --------------------//
global.settings = {
  db: {
    users: {},
    groups: {},
    settings: {},
    ...(global.db || {})
  }
}

//-------------------- [ RESPONSES ] --------------------//
global.mess = {
  done: '*Successfully Bang*',
  owner: '*Acces Ini Khusus Owner*',
  private: '*Fitur Ini Cuma Bisa Di Private Chat*',
  group: '*Fitur Ini Khusus Group*',
  botAdmin: '*Bot Belum Admin*',
  admin: '*Kamu Bukan Admin Group*',
}

//-------------------- [ HOT RELOAD CONFIG ] --------------------//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`\x1b[0;32m${__filename} \x1b[1;32mupdated!\x1b[0m`)
  delete require.cache[file]
  require(file)
})