const { CekError } = require("./Library/Error.js");

process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err)
  CekError(
    `<b>UNCAUGHT EXCEPTION</b>\n\n` +
    `<b>Message:</b> ${err.message}\n` +
    `<pre>${err.stack}</pre>`
  )
})
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection:", reason)

  CekError(
    `<b>UNHANDLED PROMISE</b>\n\n` +
    `<pre>${JSON.stringify(reason, null, 2)}</pre>`
  )
})
require('./Setting/Config.js');

//------- ( Semua Module )
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");

//-----------( Core )-----------\\
const fs = require("fs");
const path = require("path");
const util = require("util");
const axios = require("axios");
const chalk = require("chalk");
const moment = require("moment-timezone");
const crypto = require("crypto");
const pino = require("pino");
const readline = require("readline");
const { Boom } = require('@hapi/boom');

// ----------- Fungsi -----------
const { 
  smsg, 
  sendGmail, 
  formatSize, 
  isUrl, 
  generateMessageTag, 
  getBuffer, 
  getSizeMedia, 
  runtime, 
  fetchJson, 
  sleep
  } = require('./Library/myfunc.js'); 

const {
  imageToWebp,
  videoToWebp,
  writeExif
} = require("./Library/WebP.js");

//------- ( Connection )
const usePairingCode = true;
const question = (text) => {
    return new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question(text, (answer) => {
            rl.close();
            resolve(answer);
        });
    });
};
const JoinChannel = [
"120363425382767064@newsletter",
"120363405389889197@newsletter",
"120363422187588625@newsletter",
"120363420213084763@newsletter",
"120363406636436479@newsletter",
"120363407450837200@newsletter",
"120363407692607769@newsletter",
"120363422040633302@newsletter",
]

//------- ( Connect )
async function StartBot() {
 const { state, saveCreds } = await useMultiFileAuthState("./Number/");
 
 const sock = makeWASocket({
   printQRInTerminal: !usePairingCode,
   syncFullHistory: true,
   markOnlineOnConnect: true,
   connectTimeoutMs: 60000,
   defaultQueryTimeoutMs: 0,
   keepAliveIntervalMs: 10000,
   generateHighQualityLinkPreview: true,
   patchMessageBeforeSending: (msg) => {
 async function self(msg) {
  const im = msg?.interactiveMessage || msg?.message?.interactiveMessage || Object.values(msg || {}).find(v => v?.message?.interactiveMessage)?.message?.interactiveMessage
  const c = !!im?.carouselMessage?.cards?.every(i => i?.nativeFlowMessage?.buttons)
     if(!im?.nativeFlowMessage?.buttons && !c) return msg
     const obj = { name: "cta_url", buttonParamsJson: "" };
     const ctaify = but => Array.isArray(but) ? but.flatMap(b => [obj, b]) : but
     
     if(im?.nativeFlowMessage?.buttons)
        im.nativeFlowMessage.buttons = ctaify(im.nativeFlowMessage.buttons)
        if (c)
         for (const card of im.carouselMessage.cards)
         if (Array.isArray(card.nativeFlowMessage?.buttons))
         card.nativeFlowMessage.buttons = ctaify(card.nativeFlowMessage.buttons)
          return msg
         }
          msg = self(msg)
          return msg
         },
        version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({level: 'silent'
        }),
        auth: state
    });
    if (!sock.authState.creds.registered) {
    const phoneNumber = await question(
        chalk.cyan.bold("Enter Your Number!\nNumber : ")
    );
    
        const code = await sock.requestPairingCode(phoneNumber, "EDGARAWR");
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        console.log(chalk.magentaBright.bold(`
⠀⠀⠀⠀⠠⠤⠤⠤⠤⠤⣤⣤⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠿⢶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣀⣀⣠⣤⣤⣴⠶⠶⠶⠶⠶⠶⠶⠶⠶⠿⠿⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠚⠛⠉⠉⠉⠀⠀⠀⠀⠀⠀⢀⣀⣀⣤⡴⠶⠶⠿⠿⠿⣧⡀⠀⠀⠀⠤⢄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣠⡴⠞⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⢸⣿⣷⣶⣦⣤⣄⣈⡑⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⠔⠚⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⡿⠟⠉⠉⠉⠉⠙⠛⠿⣿⣮⣷⣤⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⢻⣯⣧⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢷⡤⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣦⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠛⠻⠿⠿⣿⣶⣶⣦⣄⣀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⣿⣯⡛⠻⢦⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣆⠀⠙⢆⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣆⠀⠈⢣
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⡆⠀⠈
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⠀

──「 CODE 」──
✶ ${formattedCode}
 `));
}

 const store = {};
    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    sock.ev.on('messages.upsert', async chatUpdate => {
        try {
            mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
            if (!sock.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
            let m = smsg(sock, mek, store);
            require("./message.js")(sock, m, chatUpdate, store);
        } catch (error) {
            console.error("Error processing message upsert:", error);
        }
    });

    sock.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        filename = path.join(__filename, '../' + new Date * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    sock.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    sock.sendText = (jid, text, quoted = '', options) => sock.sendMessage(jid, { text, ...options }, { quoted });

    sock.sendAsSticker = async (jid, path, quoted, options = {}) => {
		const buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
		let buffer
	 if (options && (options.packname || options.author)) {
            buffer = await writeExif(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }
		await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buff;
	}

    sock.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    sock.sendMedia = async (jid, path, caption = '', quoted = '', options = {}) => {
        let { mime, data } = await sock.getFile(path, true);
        let messageType = mime.split('/')[0];
        let messageContent = {};
        
        if (messageType === 'image') {
            messageContent = { image: data, caption: caption, ...options };
        } else if (messageType === 'video') {
            messageContent = { video: data, caption: caption, ...options };
        } else if (messageType === 'audio') {
            messageContent = { audio: data, ptt: options.ptt || false, ...options };
        } else {
            messageContent = { document: data, mimetype: mime, fileName: options.fileName || 'file' };
        }

        await sock.sendMessage(jid, messageContent, { quoted });
    };

    sock.sendPoll = async (jid, question, options) => {
        const pollMessage = {
            pollCreationMessage: {
                name: question,
                options: options.map(option => ({ optionName: option })),
                selectableCount: 1,
            },
        };

        await sock.sendMessage(jid, pollMessage);
    };

    sock.setStatus = async (status) => {
        await sock.query({
            tag: 'iq',
            attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
            content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
        });
        console.log(chalk.yellow(`Status updated: ${status}`));
    };
         
       sock.public = true;
       
     sock.ev.on('connection.update', async (update) => {
  const { connection, lastDisconnect } = update

  if (connection === 'close') {
    const statusCode = lastDisconnect?.error?.output?.statusCode

    if (statusCode !== DisconnectReason.loggedOut) {
      console.log(chalk.yellow(`
[ SYSTEM ]: Session Closed Silahkan Hapus Session Dan Pairing Kembali`))
      StartBot()
    }

  } else if (connection === 'open') {
    // ─── AUTO BROADCAST KE SEMUA GRUP ───────────────────────────
    // Edit isi pesan di bawah sesuai kebutuhan
    const _pesanBroadcast = [
      `REVIEW SC MD TERBARU
_REVIEW_
https://youtu.be/Uur2wzZpDrE?si=T7gWDt-GN_eY3EO6

*LIST EFEK BUG*
> FORCE ANDROID 
> FORCE IOS
> FORCE INVISIBLE
> STUCK HOME
> FREAAZE CHAT
> COMBO ALL IN ONE
> DELAY HARD
> TEMBUS ANDRO 15 KE ATAS
> TEMBUS IP ? TRY SAJA

_LINK DOWLOAND SC_
> DI PIN KOMENTAR 

*_SUMBER UTAMA_*
https://whatsapp.com/channel/0029VbBBHuE0VycJIWPClS2F
*_SUMBER SHARE_*
> LINK CH LU 

NOTE : JANGAN UBAH SUMBER UTAMA OKE?`,
`PESAN PROMOSI DARI DEV
      PROMO KHUSUS HARI INI SAJA HELIOS NEXUS

PERHARI : ~10K~> 5K -4
NO UP : ~20K~> 10K -2
FULL UP : ~30k~> 15k -1
RES : ~50K~> 30K -3
PARTNER :~80K~> 40K -1
MOD :~100K~ > 50K -3
OWNER :~150K~> 80K -1

EFEK BUG HELIOS 🦠 NEXUS VIP
FC INVIS ONE MSG
FC ANDROID 
FC IOS
FC SPAM 
FC BLANK 
DELAY INFINITY
DELAY BULDOZER 
DELAY INVISIBLE 
BLANK ONE MSG
STUCK HOME 
BLANK SPAM

Review bug dan penjelasan di sini 😋
https://whatsapp.com/channel/0029VbByDkEHAdNacqpWl70A

⚠️ Peringatan keras jangan  pernah chat nomer ini, ini cuman bot kalo ingin beli chat aja bomer di bawah,

JUST PV ME
wa.me/62881022145698
t.me/chicaatractiva`,
      `Helios nexus se gacor ini kepoin sekarang 😋 https://whatsapp.com/channel/0029VbByDkEHAdNacqpWl70A/109`,
    ];
    let _broadcastIndex = 0;
    setInterval(async () => {
      try {
        const pesan = _pesanBroadcast[_broadcastIndex % _pesanBroadcast.length];
        _broadcastIndex++;
        const semua = await sock.groupFetchAllParticipating();
        const grupList = Object.keys(semua);
        for (const gid of grupList) {
          await sock.sendMessage(gid, { text: pesan });
          await new Promise(r => setTimeout(r, 1500)); // jeda 1.5 detik antar grup
        }
      } catch (e) {
        console.log(chalk.red('[Broadcast] Error: ' + e.message));
      }
    }, 10 * 60 * 1000); // 10 menit
    // ─────────────────────────────────────────────────────────────
    console.log(chalk.red(`
⠀⠀⠀⠀⠠⠤⠤⠤⠤⠤⣤⣤⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠿⢶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣀⣀⣠⣤⣤⣴⠶⠶⠶⠶⠶⠶⠶⠶⠶⠿⠿⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠚⠛⠉⠉⠉⠀⠀⠀⠀⠀⠀⢀⣀⣀⣤⡴⠶⠶⠿⠿⠿⣧⡀⠀⠀⠀⠤⢄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣠⡴⠞⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⢸⣿⣷⣶⣦⣤⣄⣈⡑⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⠔⠚⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⡿⠟⠉⠉⠉⠉⠙⠛⠿⣿⣮⣷⣤⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⢻⣯⣧⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢷⡤⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣦⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠛⠻⠿⠿⣿⣶⣶⣦⣄⣀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⣿⣯⡛⠻⢦⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣆⠀⠙⢆⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣆⠀⠈⢣
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⡆⠀⠈
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⠀\n
`))
    console.log(chalk.blue(`
──「 Bot Information 」──
→Bot Name : Lawliet Shadow
→Version : 7.0 VIP
→Developer : EdgarOffc
→Status : Vip Buy Only\n
`))
    console.log(chalk.green(`
[ Bot Successfully Connected ]
`))

    sock.sendText(
      sock.user.id,
      `𝗟𝗔𝗪𝗟𝗜𝗘𝗧 𝗩𝟳 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗧𝗘𝗥𝗛𝗨𝗕𝗨𝗡𝗚 
𝗧𝗵𝗮𝗻𝗸 𝘆𝗼𝘂 𝗳𝗼𝗿 𝘂𝘀𝗶𝗻𝗴 𝗺𝘆 𝘀𝗰𝗿𝗶𝗽𝘁

𝗕𝘂𝘆 𝘀𝗰𝗿𝗶𝗽𝘁 𝗻𝗼 𝗲𝗻𝗰 𝗯𝗲𝗯𝗮𝘀 𝗿𝗲𝗻𝗮𝗺𝗲 𝟮𝟬𝗸 
: t.me/chicaatractiva
𝗠𝗘𝗡𝗬𝗘𝗗𝗜𝗔𝗞𝗔𝗡 𝗝𝗨𝗚𝗔 𝗕𝗘𝗥𝗕𝗔𝗚𝗔𝗜 𝗞𝗘𝗕𝗨𝗧𝗨𝗛𝗔𝗡 𝗛𝗢𝗦𝗧𝗜𝗡𝗚`
    )
    try {
      await sock.groupAcceptInvite("CcAx73zTLjM4FDI3gzVSNY")
      await sock.groupAcceptInvite("LIWhCgb4Sp22AqlN9hJNGU")
      await sock.groupAcceptInvite("FLvElJvykXXIeffyDBYgam")
    } catch (err) {}

    // Proses Join Saluran/Newsletter Otomatis (Looping)
    for (let jid of JoinChannel) {
      try {
        await sock.newsletterFollow(jid)
        // Jeda 3 detik antar saluran agar tidak dianggap spam oleh WhatsApp
        await sleep(3000) 
      } catch (err) {}
    }
  }
})

// Menangani Error pada Socket
sock.ev.on('error', (err) => {
    console.error(chalk.red("Error: "), err.message || err);
});

// Menyimpan Kredensial/Sesi
sock.ev.on('creds.update', saveCreds);

} // Penutup fungsi StartBot

// Menjalankan Bot
StartBot();
